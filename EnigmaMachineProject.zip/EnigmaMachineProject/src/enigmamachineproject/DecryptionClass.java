/*
Program Name: DecryptionClass
Author: Cameron Villnave
Date Written: December 2, 2020
Synopsis: This class collects and decrypts the message provided by the user
*/
package enigmamachineproject;

import static enigmamachineproject.EnigmaMachineProject.PressEnterToContinue;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class DecryptionClass {
    // create an decryptData() method
    public void decryptData() throws IOException {
        System.out.println("                    Select the number of your option: ");
        
        Scanner in = new Scanner(System.in);
        int dmsglen = 0;
        char dcurrentchar;
        int di = 0;
        String ds2 = "";
        String ds = "";
        String dnewstr = "";
        String myPlugboardin = "!<35W'7uUn18ITy(JoviPQcdXVZRYgmp02GFqwK?t4hfzkl9.MOD)LrCxEHaB,j-SNAb6es'";
        String myPlugboardout = "T9!U(h,fvJzM'4Oe6F3scAS25ntlrH1gR).CWENaIj7DXxYuyidVQK8-PZ'pLbB0wkmo<?Gq";

        int numbentered = in.nextInt();
        Scanner myMessage = new Scanner(System.in);  // Create a Scanner object
        Scanner myFile = new Scanner(System.in);
        if (numbentered == 1) {
            //String fname = "/Users/cameronvillnave/Desktop/ScreenBuilder/DecryptionMessage.txt";

            System.out.println("Enter the message to be decrypted ");
            String decryptMessage = myMessage.nextLine();  // Read user input
            System.out.println("Message to be decrypted is : " + decryptMessage);  // Output user input 
            EnigmaMachineProject myscr2 = new EnigmaMachineProject();
            dmsglen = decryptMessage.length();
        
            for(int dcurrposition=dmsglen-1;dcurrposition>=0;dcurrposition--) { 
                dcurrentchar = decryptMessage.charAt(dcurrposition);
                ds = String.valueOf(dcurrentchar);
                di=myPlugboardout.indexOf(ds, 0);
                ds2 = myPlugboardin.substring(di, di+1);
                dnewstr = ds2 + dnewstr;
        } 
        String dnewMessage = dnewstr.replace("<"," ");
                // put code here that puts the /n back in

        System.out.println("decrypted message is: " + dnewMessage);
            
        } else {
            if (numbentered == 2) {
                String returnMessage = "";
                System.out.println("Enter the complete path and filename of the file to be decrypted ");
                String decryptFile = myFile.nextLine();  // Read user input
                System.out.println("File to be decrypted is : " + decryptFile);  // Output user input
                try {
                File myObj = new File(decryptFile);
                Scanner myReader = new Scanner(myObj); 
                    while (myReader.hasNextLine()) {
                        String data = myReader.nextLine();
                        returnMessage = returnMessage + data;
                }
                myReader.close();
                } catch (FileNotFoundException e)  {
                    System.out.println("File not found");
                    System.out.println("Returning to Main Menu");
                    MainMenuScreen.PressEnterToContinue();
                    MainMenuScreen myMenu = new MainMenuScreen();
                    myMenu.MainMenuScreen();                
                }
                dmsglen = returnMessage.length();
                returnMessage = returnMessage.replace(" ","<");
        
                for(int dcurrposition=dmsglen-1;dcurrposition>=0;dcurrposition--) { 
                    //String decryptFileout = "";
                    dcurrentchar = returnMessage.charAt(dcurrposition);
                    ds = String.valueOf(dcurrentchar);
                    di=myPlugboardout.indexOf(ds, 0);
                    ds2 = myPlugboardin.substring(di, di+1);
                    dnewstr = ds2 + dnewstr;
                } 
                // put code here that puts the /n back in
                dnewstr = dnewstr.replace("<"," ");

                System.out.println("decrypted message is: " + dnewstr);

            } else {
                 if (numbentered == 3) {
                      String[] args = null;
                     MainMenuScreen myMenu = new MainMenuScreen();
                     myMenu.MainMenuScreen();
                     
                     
                 }

            }
    }
            File myObj = new File("DecryptedMessage.txt");
            myObj.delete();
             if (myObj.createNewFile()) {
                 System.out.println("File created: " + myObj.getName());
             } else {
                 System.out.println("File already exists.");
             }
            
            
            try (FileWriter myWriter = new FileWriter("DecryptedMessage.txt")) {
                myWriter.write(dnewstr);
            }
            String fmessage = "";
            String currvalue = "";
            char fcurrchar;
            int flen = dnewstr.length();
            int ccounter = 0;
            int pos = 0;
            for(int dcurrposition=pos;dcurrposition<flen;dcurrposition++) { 
                ccounter ++;
{
                    fcurrchar = dnewstr.charAt(dcurrposition);
                    currvalue = String.valueOf(fcurrchar);
                    fmessage = fmessage + currvalue;

                if (ccounter > 60) {
                    if (currvalue.equals(" ")) {
                        currvalue="\n";
                        ccounter = 0;
                        fmessage = fmessage + currvalue;
                    } else {
                        ccounter++;
                    }
                }
}}  
                
            
            EnigmaMachineProject myscr = new EnigmaMachineProject();
            myscr.painter("/Users/cameronvillnave/Desktop/ScreenBuilder/BlankScreen.txt");

             System.out.println("             —————————————————————————————————————————————————————————————————————————————-\n" +
"");
             System.out.println("            Project: EnigmaMachine CIS220M                             by Cameron Villnave \n" + "");
             System.out.println("            ScreenName: OutputScreen                                    Date: Nov 11, 2020 ");
             System.out.println("    ");
             
             System.out.println("        " + (fmessage));
 
        PressEnterToContinue();
        System.out.println("Returning to main menu");
        MainMenuScreen myMenu = new MainMenuScreen();
        myMenu.MainMenuScreen();
             

}}
    
    
    
   