/*
Program Name: MainMenuScreen
Author: Cameron Villnave
Date Written: December 2, 2020
Synopsis: Sets up the main menu
*/

package enigmamachineproject;

import java.io.IOException;
import java.util.Scanner;

public class MainMenuScreen {
    public void MainMenuScreen() throws IOException {
        EnigmaMachineProject myscr2 = new EnigmaMachineProject();
        int numbentered;
        myscr2.painter("/Users/cameronvillnave/Desktop/ScreenBuilder/MainMenuScreen.txt");
        System.out.println("                    Enter the number of the program you would like to run: ");
        Scanner in = new Scanner(System.in);
        numbentered = in.nextInt();
        if (numbentered == 1) {
            myscr2.painter("/Users/cameronvillnave/Desktop/ScreenBuilder/InformationScreen.txt");
            PressEnterToContinue();
            myscr2.painter("/Users/cameronvillnave/Desktop/ScreenBuilder/EncryptionScreen.txt");
           EncryptionClass encrypter = new EncryptionClass();
           encrypter.encryptData();
        } else {
            if (numbentered == 2) {
            myscr2.painter("/Users/cameronvillnave/Desktop/ScreenBuilder/InformationScreen.txt");
            PressEnterToContinue();
            myscr2.painter("/Users/cameronvillnave/Desktop/ScreenBuilder/DecryptionScreen.txt"); 
            DecryptionClass decrypter = new DecryptionClass();
            decrypter.decryptData();
            } else {
                if (numbentered == 3) {
                    myscr2.painter("/Users/cameronvillnave/Desktop/ScreenBuilder/ExitScreen.txt");    
                    PressEnterToContinue();
                    System.exit(0);
                }}}}
public static void PressEnterToContinue() {
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    
            System.out.println("Press the Enter key to continue...");
        try
        {
            System.in.read();
        }  
        catch(IOException e)
        {}  
    }}

        

