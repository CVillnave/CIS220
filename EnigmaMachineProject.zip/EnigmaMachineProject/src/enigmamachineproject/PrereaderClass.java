package enigmamachineproject;


import static enigmamachineproject.LookUp.lookUp;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class PrereaderClass {
    
    static void preread(String encryptMessage, String encryptFile, String encryptType) throws FileNotFoundException, IOException {   
    
        // if the encrypttype is a File (="F") then we need to read the file and store it in encryptMessage
        String returnMessage = "";
        if(encryptType=="F")
    {
            try {
            File myObj = new File(encryptFile);
            Scanner myReader = new Scanner(myObj); 
                while (myReader.hasNextLine()) {
                    String data = myReader.nextLine();
                    returnMessage = returnMessage + data;
                }
                myReader.close();
            } catch (FileNotFoundException e)  {
                System.out.println("File not found");
                System.out.println("Returning to Main Menu");
                MainMenuScreen.PressEnterToContinue();
                MainMenuScreen myMenu = new MainMenuScreen();
                myMenu.MainMenuScreen();                
                }
            //MainMenuScreen.PressEnterToContinue();

            //Logger.getLogger(PrereaderClass.class.getName()).log(Level.SEVERE, null, ex);
       // }

        encryptMessage=returnMessage;
    }
    //String invalidchars = "";    
 
   ArrayList<String> validchars = new ArrayList<>(); // creates an array list object
   validchars.add("<");
   validchars.add("!");
   validchars.add("'");
   validchars.add("(");
   validchars.add(")");
   validchars.add(".");
   validchars.add("-");
   validchars.add(",");
   validchars.add("0");
   validchars.add("1");
   validchars.add("2");
   validchars.add("3");
   validchars.add("4");
   validchars.add("5");
   validchars.add("6");
   validchars.add("7");
   validchars.add("8");
   validchars.add("9");
   validchars.add("?");
   validchars.add("A");
   validchars.add("B");
   validchars.add("C");
   validchars.add("D");
   validchars.add("E");
   validchars.add("F");
   validchars.add("G");
   validchars.add("H");
   validchars.add("I");
   validchars.add("J");
   validchars.add("K");
   validchars.add("L");
   validchars.add("M");
   validchars.add("N");
   validchars.add("O");
   validchars.add("P");
   validchars.add("Q");
   validchars.add("R");
   validchars.add("S");
   validchars.add("T");
   validchars.add("U");
   validchars.add("V");
   validchars.add("W");
   validchars.add("X");
   validchars.add("Y");
   validchars.add("Z");
   validchars.add("a");
   validchars.add("b");
   validchars.add("c");
   validchars.add("d");
   validchars.add("e");
   validchars.add("f");
   validchars.add("g");
   validchars.add("h");
   validchars.add("i");
   validchars.add("j");
   validchars.add("k");
   validchars.add("l");
   validchars.add("m");
   validchars.add("n");
   validchars.add("o");
   validchars.add("p");
   validchars.add("q");
   validchars.add("r");
   validchars.add("s");
   validchars.add("t");
   validchars.add("u");
   validchars.add("v");
   validchars.add("w");
   validchars.add("x");
   validchars.add("y");
   validchars.add("z");
   validchars.add(" ");
   validchars.add("/");
   
     
    for (int i = encryptMessage.length() - 1; i >= 0; i--) {
    
    //char currchar = encryptMessage.charAt(currposition);
    
    if(lookUp(encryptMessage))
    //if(validchars.contains(i)
        
    {
        //JOptionPane.showMessageDialog(null,"Message is Valid");
        // if all the characters are valid call the Encryption Class
    }
    else
    {
        JOptionPane.showMessageDialog(null,"Message has invalid characters - please try again");
        //invalidchars = invalidchars + encryptMessage.charAt(i);
        //System.out.println("Invalid characters = " + invalidchars);
        MainMenuScreen.PressEnterToContinue();
        System.out.println("Returning to main menu");
        MainMenuScreen myMenu = new MainMenuScreen();
        myMenu.MainMenuScreen();

        
        break;
        
    }
    }
    
}


}

