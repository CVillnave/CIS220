/*
Project Name: EnigmaMachine
Author: Cameron Villnave
Date Written: December 2, 2020
Synopsis: This program is the starting program for the Enigma Machine
*/

package enigmamachineproject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.JOptionPane;
import java.util.Scanner;    
import java.util.logging.Level;
import java.util.logging.Logger;

// this is the parent class. it is extended in the child class EnigmaMachineProject. 

// basically everything that happens here can be used by the code below; basically I don't have to keep copying 
// this code down below

// this small snippet of code is being reused over and over again because of inheritance
// so the program doesnt have to keep repeating code every time the program paints a screen
class ScreenPainter {
      void painter(String fname) throws FileNotFoundException, IOException {
      if (System.getProperty("os.name").contains("Windows")) {
          try {
              new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
          } catch (InterruptedException ex) {
              Logger.getLogger(ScreenPainter.class.getName()).log(Level.SEVERE, null, ex);
         }}
      else {
        File blnkscr = new File("/Users/cameronvillnave/Desktop/ScreenBuilder/BlankScreen.txt");
        BufferedReader br1 = new BufferedReader(new FileReader(blnkscr));
        String st1;
        st1 = br1.readLine();
        while (st1 != null) {
            st1 = br1.readLine();
            if (st1 != null)
                System.out.println(st1);
        }}
 
        File infile = new File(fname);
        BufferedReader br2 = new BufferedReader(new FileReader(infile));
        String st2;
        st2 = br2.readLine();
        while (st2 != null) {
            st2 = br2.readLine();
            if (st2 != null)
                System.out.println(st2); 
        }
      }   } 
// inheritance is being used here to paint the screens and to drive the process
class EnigmaMachineProject extends ScreenPainter {
    public static void main(String[] args) throws IOException {
        EnigmaMachineProject myscr = new EnigmaMachineProject();
        myscr.painter("/Users/cameronvillnave/Desktop/ScreenBuilder/WelcomeScreen.txt");
        PressEnterToContinue(); 
        MainMenuScreen myMenu = new MainMenuScreen();
        myMenu.MainMenuScreen();
    
        Scanner myObj = new Scanner(System.in);  // Create a Scanner object
        int menuSelection = myObj.nextInt();  // Read user input
        System.out.println("Option selected is: " + menuSelection);  // Output user input     

    
        
        EncryptionClass myEMessage = new EncryptionClass();
        DecryptionClass myDMessage = new DecryptionClass();
    
        if (menuSelection == 1) {               
            // this is where you will call the method to obtain the message to be encrypted
            myEMessage.encryptData();
            myMenu.MainMenuScreen();
            
// call the class or method to do the encryption
// paint the encrypted output to the output screen
// After they press enter return to the main menu
                
        } 
        else if (menuSelection == 2) {
        // this is where you will call the method to obtain to message to be decrypted
            myDMessage.decryptData();
            myMenu.MainMenuScreen();

// call the class or method to do the decryption
// paint the decrypted output to the output screen
// After they press enter return to the main menu

        } else { 
        
        // this where you will exit the program        
            java.lang.System.exit(0);
    
    }
    }
    
    
    

public static boolean lookUp(String input)
{
    String table[] = {"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"};
    boolean valid = false;
        
    for(int i = 0; i < table.length; i++)
    {
        if(input.equals(table[i]))
        {
            valid = true;
        
        }
    }

    return valid;
}

    // this code allows the user to read the screen and press enter to continue through the program
    public static void PressEnterToContinue() {
    
            System.out.println("Press the Enter key to continue...");
        try
        {
            System.in.read();
        }  
        catch(IOException e)
        {}  
    }}
    