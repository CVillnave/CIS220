package enigmamachineproject;

import java.util.ArrayList;


public class LookUp {
    
    public static boolean lookUp(String encryptMessage)
{
    ArrayList<String> validchars = new ArrayList<String>(); // creates an array list object
    validchars.add("<");
    validchars.add("!");
    validchars.add("'");
    validchars.add("(");
    validchars.add(")");
    validchars.add(".");
    validchars.add("-");
    validchars.add(",");
    validchars.add("0");
    validchars.add("1");
    validchars.add("2");
    validchars.add("3");
    validchars.add("4");
    validchars.add("5");
    validchars.add("6");
    validchars.add("7");
    validchars.add("8");
    validchars.add("9");
    validchars.add("?");
    validchars.add("A");
    validchars.add("B");
    validchars.add("C");
    validchars.add("D");
    validchars.add("E");
    validchars.add("F");
    validchars.add("G");
    validchars.add("H");
    validchars.add("I");
    validchars.add("J");
    validchars.add("K");
    validchars.add("L");
    validchars.add("M");
    validchars.add("N");
    validchars.add("O");
    validchars.add("P");
    validchars.add("Q");
    validchars.add("R");
    validchars.add("S");
    validchars.add("T");
    validchars.add("U");
    validchars.add("V");
    validchars.add("W");
    validchars.add("X");
    validchars.add("Y");
    validchars.add("Z");
    validchars.add("a");
    validchars.add("b");
    validchars.add("c");
    validchars.add("d");
    validchars.add("e");
    validchars.add("f");
    validchars.add("g");
    validchars.add("h");
    validchars.add("i");
    validchars.add("j");
    validchars.add("k");
    validchars.add("l");
    validchars.add("m");
    validchars.add("n");
    validchars.add("o");
    validchars.add("p");
    validchars.add("q");
    validchars.add("r");
    validchars.add("s");
    validchars.add("t");
    validchars.add("u");
    validchars.add("v");
    validchars.add("w");
    validchars.add("x");
    validchars.add("y");
    validchars.add("z");
    validchars.add(" ");
    validchars.add("/");

    String table[] = {" ","<","!","'","(",")",".","-",",","0","1","2","3","4","5","6","7","8","9","?","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z","a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","/"};
    boolean valid = false;
    boolean found;
    //boolean found = validchars.contains(encryptMessage);
    
    for(int i = 0; i < table.length; i++)
    {
        for (int currposition = encryptMessage.length()-1; currposition>=0; currposition--) {
            char currchar = encryptMessage.charAt(currposition);
            String s = String.valueOf(currchar);  
            //if(s.equals(table[i]))
            if(found=validchars.contains(s)) 
            {
                     valid = true;
               }
            else
            {
                valid = false;
                break;
                //return valid;
            }
              
        }
   
    }
    
    return valid;
    }
    

    
}
