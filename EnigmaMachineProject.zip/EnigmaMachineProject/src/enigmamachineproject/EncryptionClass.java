/*
Program Name: EncryptionClass
Author: Cameron Villnave
Date Written: December 2, 2020
Synopsis: This class collects and encrypts the message provided by the user
 */
package enigmamachineproject;

import static enigmamachineproject.EnigmaMachineProject.PressEnterToContinue;
import java.io.IOException;
import java.util.Scanner;
import java.io.File; 
import java.io.FileNotFoundException;
import java.io.FileWriter;

public class EncryptionClass {
    // create an encryptData() method
    public void encryptData() throws IOException {
        System.out.println("                    Select the number of your option: ");
        Scanner in = new Scanner(System.in);
        int numbentered = in.nextInt();
        String encryptType = "";
        String encryptFile = "";
        String encryptMessage = "";
        Scanner myMessage = new Scanner(System.in);  // Create a Scanner object
        Scanner myFile = new Scanner(System.in);
        if (numbentered == 1) {
            System.out.println("Enter the message to be encrypted ");
            encryptMessage = myMessage.nextLine();  // Read user input
            PrereaderClass myprereader = new PrereaderClass();
            encryptType = "M";
            myprereader.preread(encryptMessage, encryptFile, encryptType);
            System.out.println("Message to be encrypted is : " + encryptMessage);  // Output user input
        } else if (numbentered == 2) { 
            
            System.out.println("Enter the complete path and filename of the file to be encrypted ");
            encryptFile = myFile.nextLine();  // Read user input
            System.out.println("File to be encrypted is : " + encryptFile);  // Output user input   
            PrereaderClass myprereader = new PrereaderClass();
            encryptType = "F";
            myprereader.preread(encryptMessage, encryptFile, encryptType);
            System.out.println("Message to be encrypted is");
            System.out.println(encryptFile);
            
            //File file = new File(encryptFile);
            //Scanner sc = new Scanner(file); 
            
            //while (sc.hasNextLine()) 
              //  System.out.println(sc.nextLine()); 
            
            } else {
                 if (numbentered == 3) {
                     String[] args = null;
                     MainMenuScreen myMenu = new MainMenuScreen();
                     myMenu.MainMenuScreen();
                      System.out.println("                    Enter the number of the program you would like to run: ");
                 
                 }}
        String myPlugboardin = "!<35W'7uUn18ITy(JoviPQcdXVZRYgmp02GFqwK?t4hfzkl9.MOD)LrCxEHaB,j-SNAb6es'";
        String myPlugboardout = "T9!U(h,fvJzM'4Oe6F3scAS25ntlrH1gR).CWENaIj7DXxYuyidVQK8-PZ'pLbB0wkmo<?Gq";
        String returnMessage ="";
        if(encryptType=="F")
    {
            try {
            File myObj = new File(encryptFile);
            Scanner myReader = new Scanner(myObj); 
                while (myReader.hasNextLine()) {
                    String data = myReader.nextLine();
                    returnMessage = returnMessage + data;
                }
                myReader.close();
            } catch (FileNotFoundException e)  {
                System.out.println("File not found");
                System.out.println("Returning to Main Menu");
                MainMenuScreen.PressEnterToContinue();
                MainMenuScreen myMenu = new MainMenuScreen();
                myMenu.MainMenuScreen();                
                }
            encryptMessage = returnMessage;
    }
        
 
        String newMessage = "";
        
        newMessage = encryptMessage.replace(" ","<");
        newMessage = newMessage.replace("\n","");
       
        String decryptMessage = "";
        String s = "";
        String ds = "";
        int di = 0;
        int i = 0;
        char currentchar;
        char dcurrentchar;

        char newchar;
        String newstr="";
        String dnewstr="";
        String Emsg = "";
        String s2 = "";
        String ds2 = "";
        int inlen = 0;
        int outlen = 0;
        int dmsglen = 0;
  
// encryption code below        
        int pblen = myPlugboardin.length();
        int msglen = newMessage.length();
        for(int currposition=msglen-1;currposition>=0;currposition--) { 
            currentchar = newMessage.charAt(currposition);
            s = String.valueOf(currentchar);
            i=myPlugboardin.indexOf(s, 0);
            s2 = myPlugboardout.substring(i, i+1);
            newstr = s2 + newstr;
        } 
        System.out.println("encrypted message is: " + newstr);
        
        String encryptedMessage = newstr;
        System.out.println("encrypted message is: " + newstr);
        
        
        String replaceMessage = encryptedMessage;
        // code below will parse the message according to the specs
        String parsedMessage ="";
        int insertspace = 1;
        for (int i2 = 0; i2 < replaceMessage.length(); i2++) {

            insertspace=insertspace+1;
            parsedMessage = parsedMessage+replaceMessage.charAt(i2);
            if(insertspace==7) {
                parsedMessage = parsedMessage+" ";
                insertspace=1;
        
                
            }
        }
            System.out.println("Parsed message is: " + parsedMessage);
            
            
            File myObj = new File("EncryptedMessage.txt");
            myObj.delete();
             if (myObj.createNewFile()) {
                 System.out.println("File created: " + myObj.getName());
             } else {
                 System.out.println("File already exists.");
             }
            
            
            try (FileWriter myWriter = new FileWriter("EncryptedMessage.txt")) {
                myWriter.write(encryptedMessage);
            }
            
            String formattedMessage="";
            String replaceMessage2 = parsedMessage;
            int insertnewline = 0;
            
            int msgLength = 0;
            msgLength = parsedMessage.length();
            System.out.println(parsedMessage);
            for (int i3 = 0; i3 < parsedMessage.length(); i3++) {
                insertnewline=insertnewline+1;
                formattedMessage = formattedMessage+replaceMessage2.charAt(i3);
                if(insertnewline==70) {
                    formattedMessage = formattedMessage+"\n";
                    formattedMessage = formattedMessage+"                ";
                    insertnewline=0;
        
                }    
            }
            
            System.out.println("Successfully wrote to the file.");
            EnigmaMachineProject myscr = new EnigmaMachineProject();
            myscr.painter("/Users/cameronvillnave/Desktop/ScreenBuilder/BlankScreen.txt");

             System.out.println("             —————————————————————————————————————————————————————————————————————————————-\n" +
"");
             System.out.println("            Project: EnigmaMachine CIS220M                             by Cameron Villnave");
             System.out.println("            ScreenName: OutputScreen                                    Date: Nov 11, 2020 \n" + "");
             System.out.println("    ");
             
             System.out.println("                " + formattedMessage);


        PressEnterToContinue();
        System.out.println("Returning to main menu");
        MainMenuScreen myMenu = new MainMenuScreen();
        myMenu.MainMenuScreen();
             
    }
    public static boolean lookUp(String input)
{
    String table[] = {" ","<","!","'","(",")",".","-",",","0","1","2","3","4","5","6","7","8","9","?","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z","a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","/"};    boolean valid = false;
        
    for(int i = 0; i < table.length; i++)
    {
        if(input.equals(table[i]))
        {
            
            valid = true;
        
        }
    }

    return valid;
}

    }
        

